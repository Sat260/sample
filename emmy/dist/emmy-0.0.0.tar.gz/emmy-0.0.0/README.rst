####
Emmy
####

|coverage_badge|

A 3D modeling library for medical images, CAD, FEA, and CFD.

.. |coverage_badge| image:: https://img.shields.io/endpoint?url=https://gist.githubusercontent.com/adamgranthendry/df51d4eadf024e859f77d7c90bae6577/raw/coverage_badge.json
   :alt: Code Coverage
