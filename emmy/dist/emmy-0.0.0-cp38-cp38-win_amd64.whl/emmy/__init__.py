"""A 3D modeling library for medical images, CAD, FEA, and CFD."""

from __future__ import annotations  # pragma: no cover

__version__ = '0.0.0'  # pragma: no cover
