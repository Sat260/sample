"""``emmy``'s entry point script."""

from __future__ import annotations


def main() -> None:
    """The entry point script."""


if __name__ == '__main__':
    main()
