"""Unit tests for ``sphinx`` documentation."""

from __future__ import annotations
